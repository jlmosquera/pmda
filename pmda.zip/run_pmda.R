#!/usr/bin/env Rscript


pmda <- function()
{
   cat("----------------------------------\n")
   cat("Begin execution of the pipeline\n")
   cat("----------------------------------\n\n")
   
   source("./parameters.R")
   cat("0. Parameters loaded\n")
  
   source("./routines/proc1_qc_raw_data.R")
   cat("1. Quality control of raw reads done\n")
   
   source("./routines/proc2_preprocessing_filtering_raw_reads.R")
   cat("2.1. Preprocessing - filtering raw reads done\n")
    
   source("./routines/proc2_preprocessing_splitting_and_trimming_reads.R")
   cat("2.2. Preprocessing - splitting and trimming reads done\n")
   
   source("./routines/proc3_alignment.R")
   cat("3. Aligment with BiQ Analyzer HT done\n")

   source("./routines/proc4_quantification.R")
   cat("4. Quantification done\n")

   source("./routines/proc5_comparisons.R")
   cat("5. Selection of DMRs done\n")

   cat("----------------------------------\n")
   cat("End execution of the pipeline\n")
   cat("----------------------------------\n\n")
}

pmda()

