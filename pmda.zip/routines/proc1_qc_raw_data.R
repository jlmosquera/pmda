## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Process 1 : Quality control of raw reads generated  by a 454 GS FLX System from Roche.
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.


###################################################
## chunk 1: Create main output paths
###################################################

.qcr    <- file.path(.res, "qc.raw")

if(!file.exists(.res)) dir.create(.res)
if(!file.exists(.qcr)) dir.create(.qcr)


###################################################
## chunk 2: Load Packages
###################################################

library("ShortRead")
library("tools")
library("reshape2")


###################################################
## chunk 3: Load Functions
###################################################

source(file.path(.r, "qc.R"))


###################################################
## chunk 4: FastQC of raw reads 
###################################################

if(run.FastQC.raw)
{
    if(convert.to.fastq)
    {
        buildFastq(pl.dir = .perl,
                   fasta.fn = file.path(.run, fasta.fn),
                   qual.fn = file.path(.run, qual.fn),
                   fastq.fn = file.path(.run, fastq.fn))
    }
    
    .fastqc.raw <- file.path(.qcr, "fastqc_raw_reads")
    if(!file.exists(.fastqc.raw)) dir.create(.fastqc.raw)
    
    runFastQC(fastq.fn = file.path(.run, fastq.fn),
              res.dir = .fastqc.raw, fastqc.dir = .fastqc,
              mc.cores = mc.cores)
    
    ## Remove unnecessary objects
  
    rm(.fastqc.raw)
    gc()
}


##################################################
## chunk 4: Load Data Files
##################################################

lanes <- read.csv2(file = file.path(.dat, lanes.fn),
                   header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

if(save.reads)
{
    if(!is.null(fastq.fn))
    {
        fastq <- readFastq(.run, pattern = fastq.fn, withIds = TRUE)
        
        reads.lane <- lapply(lanes$FileName,
                             function(lane, fastq)
                             {
                                 out <- sread(fastq)
                                 names(out) <- id(fastq)
                         
                                 return(out)
                             }, fastq = fastq)
        names(reads.lane) <- gsub(paste0(".", file_ext(lanes$FileName), "$"), "", lanes$FileName)
        
        save(reads.lane, fastq, file = file.path(.dat, "reads.Rda"))
    }else{
        reads.lane <- lapply(lanes$FileName,
                             function(lane, fn)
                             {
                                 out <- readDNAStringSet(file = file.path(.run, fasta.fn), "fasta")
                                   
                                 return(out)
                             }, fasta.fn = fasta.fn)
        
        names(reads.lane) <- gsub(paste0(".", file_ext(lanes$FileName), "$"), "", lanes$FileName)
        
        save(reads.lane, file = file.path(.dat, "reads.Rda"))
    }
}else{
    load(file = file.path(.dat, "reads.Rda"))
}
  
gc()


###################################################
## chunk 6: QC of raw reads 
###################################################

if(run.QC.raw)
{
  ## Descriptive statistics of reads per lane
  
  wd.ls <- lapply(reads.lane, width)
  wd.stats.ls <- lapply(reads.lane, readsStats)
  wd.stats <- do.call("rbind", wd.stats.ls)
    
  write.csv2(x = wd.stats,
               file = file.path(.qcr, "descriptive.reads.csv"),
               quote = FALSE,
               row.names = TRUE)
  
  ## Distribution of reads per each lane
  
  wd.dist.ls <- lapply(reads.lane, readsDist)

  for(lane in names(reads.lane))
  {
      write.csv2(x = wd.dist.ls[[lane]],
                 file = file.path(.qcr, paste("distribution", lane, "csv", sep = ".")),
                 quote = FALSE,
                 row.names = FALSE)
  }

  ## Histogram of read lengths per each lane
  
  for(lane in names(reads.lane))
  {
      reads <- reads.lane[[lane]]

      wd <- width(reads)
      den.wd <- density(wd)
      tbl <- table(wd)
  
      dist.wd <- data.frame(CummulativeProportion = seq_len(length(reads)) / length(reads),
                            Width = sort(wd))

      readLengthsPlot(x = reads,
                      file = file.path(.qcr, paste("histogram.read.lengths", lane, "pdf", sep = ".")),
                      stats = wd.stats)
  }

  if(!is.null(fastq.fn))
  {
      qa.summary <- qa(file.path(.run, "reads.fastq"),type = "fastq")

      ## Density of Overall Read Quality per Lane
      
      readQualityPlot(x = qa.summary[["readQualityScore"]],
                      file = file.path(.qcr, "density.overall.read.quality.pdf"))

      ## Base call frequency over all reads per each lane
      
      bcf <- baseCallsFreq(x = qa.summary[["baseCalls"]],
                           file = file.path(.qcr, "base.call.frequency.table.csv"))
      
      baseCallsPlot(x = qa.summary[["baseCalls"]],
                   file = file.path(.qcr, "base.call.frequency.plot.pdf"))

      ## Remove unnecessary objects

      rm(qa.summary, bcf)
  }
  
  ## Remove unnecessary objects
  
  rm(wd.ls, wd.stats.ls, wd.stats, wd.dist.ls, reads, wd, den.wd, tbl, dist.wd)
  gc()
}
