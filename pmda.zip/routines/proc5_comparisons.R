## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
## 
##     Process 5 : Comparisons between experimental conditions in order to identify DMR
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.


###################################################
## chunk 1: Create main output paths
###################################################

.cmp  <- file.path(.res, "comparisons")

if(!file.exists(.cmp)) dir.create(.cmp)


###################################################
## chunk 2 : Load Packages
###################################################

library("parallel")


###################################################
## chunk 3: Load Functions
###################################################

source(file.path(.r, "quantification.R"))
source(file.path(.r, "comparisons.R"))


##################################################
## chunk 4: Load Data
##################################################

if(load.data)
{
    comp.df <- read.table(file = file.path(.dat, comparisons.fn), header = TRUE, sep = "\t")
    load(file = file.path(.dat, "met.summary.Rda"))

    gc()
}
  

###################################################
## chunk 5: Comparisons
###################################################

if(runC)
{
    ## Crosstables of methylation by context and amplicon for each site
    
    crosstab.site <- crosstabsBySite(x = met.summary.ls, mc.cores = mc.cores)

    tables.to.test <- tables2Test(x = crosstab.site, comp = comp.df, mc.cores = 6)
    fisher.test.ls <- fisherTest(x = tables.to.test, mc.cores = mc.cores)
    
    comparisons.ls <- mtCorrection(x = fisher.test.ls, method = "fdr", mc.cores = mc.cores)

    ## Write summary
      
    write.csv.ls(x = comparisons.ls, path = .cmp, suffix = "Comparisons",
                 row.names = TRUE, mc.cores = mc.cores)

    ## Summary DMR
    
    summary.dmr <- summaryDMR(x = comparisons.ls, mc.cores = mc.cores)

    ## Write summary DMR
    
    write.csv2(x = summary.dmr,
               file = file.path(.cmp, "numDMR.csv"),
               quote = FALSE,
               row.names = FALSE)
    
    gc()
}


###################################################
## chunk 6: Plot Odds Ratios
###################################################

if(runPOR)
{
    plotlistOR(x = comparisons.ls, mc.cores = mc.cores, plotPDF = FALSE)

    gc()
}

