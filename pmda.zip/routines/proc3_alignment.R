## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Process 3 : this script calls software tool 'BiQ Analyzer HT' from the Max Plank Institut Informatik
##     (http://biq-analyzer-ht.bioinf.mpi-inf.mpg.de/) for performing the aligment of reads treated
##     with bisulphite agaisnt the reference sequence(s)
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.


###################################################
## chunk 1: Create main output paths
###################################################

.dat.align <- file.path(.dat, "alignment")

.res.align <- file.path(.res, "alignment")

if(!file.exists(.dat.align)) dir.create(.dat.align)
if(!file.exists(.res.align)) dir.create(.res.align)


##################################################
## chunk 2: Load Data
##################################################

samples <- read.csv2(file = file.path(.dat, samples.fn),
                     header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

gc()


##################################################
## chunk 3: Alignment with BiQ Analyzer HT
##################################################

for(context in cpg)
{
    for(amplicon in unique(samples$Ampl.Name))
    {
        samples.amplicon <- samples[samples$Ampl.Name==amplicon, ]
        for(mid.i in paste0("MID.", samples.amplicon$MID.ID))
        {
            system(paste("java -jar -Xmx4g", file.path(.biq, "BiQ_Analyzer.jar"), "-nogui",
                         "-rseq", file.path(.dat, paste0(amplicon, ".fasta")),
                         "-bseq", file.path(.dat.align, file.path(amplicon,
                                                                  paste(amplicon, mid.i,
                                                                        "fasta", sep = "."))),
                         "-outdir", file.path(file.path(file.path(.res.align,
                                                                  context), amplicon), mid.i),
                         "-context", context) )
        }
    }
}

## Remove unnecessary objects

rm(context, amplicon, samples.amplicon, mid.i)
gc()

