## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Functions required by the Step number 3 of the pipeline - Preprocessing: splitting and trimming reads
##     (i.e. file proc2-preprocessing_splitting_and_trimming.R)
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.
##
## List of functions
##
##     splitByMIDs
##     primersDiagram
##     trimMIDs
##     splitByConsesus
##     summaryReads
##     consensusDiagram


## splitByMIDs
##
## Description
##
##     Splits reads in a'ShortReadQ' object by MID primers provided ina data.frame.
##
## Usage
##
##     splitByMIDs(fq, mids, max.start.pos, max.mm, with.indels)
##
## Parameters
##
##                fq : 'ShortReadQ' object.
##              mids : data.frame with identification (MID.ID) and sequence (MID.Seq) corresponding with each MID.
##     max.start.pos : integer indicating the maximum starting position of MID primer in the reads. By default it is 5.
##            max.mm : integer indicating the mMaximum number of mismatches in each MID primer site. By default it is 0.
##       with.indels : logical value indicating if indels are allowed in MID primer. By default it is FALSE.
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##     fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##     mids <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##     splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)

splitByMIDs <- function(fq, mids, max.start.pos = 2, max.mm = 0, with.indels = FALSE)
{
    max.mid.len <- max(unlist(lapply(mids$MID.Seq, nchar)))

    out <- list()
    for(i in 1:nrow(mids))
    {
        reads <- sread(fq)
        prefix <- DNAStringSet(substr(reads, 1, max.mid.len + max.start.pos))
        hits <- vcountPattern(mids$MID.Seq[i], prefix, max.mismatch = max.mm,
                              with.indels = with.indels)
        out[[i]] <- fq[-which(hits==0)]
        fq <- fq[-which(hits!=0)]
    }
    out[[i + 1]] <- fq

    names(out) <- c(rownames(mids), "MID.0")

    return(out)
}

## primersDiagram
##
## Description
##
##   Yields a pdf file with a bar plot of the number of reads identified for each MID primer
##
## Usage
##
##   primersDiagram(x, file, main = "Bar Plot of the number of reads by primer", freqs = FALSE)
##
## Parameters
##
##        x : data.frame associated with the slot of 'baseCalls' from a 'FastqQA' object
##     file : name of the output (.pdf) file where figures are saved
##     main : main title of the plot
##    freqs : logical value indicating if plot should show either absolute or relative frequencies
##            If TRUE, relative frequencies are show. FALSE otherwise. By deafult it is FALSE
##
## Details
##    Bar associted with those reads that have no been identified is highlighted in dark grey color,
##    and those bars associated with MIDs whose number of reads are lower than percentil 0.01 over all
##    number of reads are plotted in red color
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##    mids <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    reads.mid <- splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)
##
##    primersDiagram(x = unlist(lapply(reads.mid, length)), file = "reads.by.MID.pdf")
##
##

primersDiagram <- function(x, file, main = "Bar Plot of the number of reads by primer", freqs = FALSE)
{
    if(freqs)
    {
        f <- x / sums(x)
    }else{
        f <- x
    }

    q <- quantile(f, p = 0.01)
    cols <- c("grey", grey.colors(1))[(names(f)=="MID.0") + 1]
    cols[f < q] <- "tomato"

    pdf(file)
        barplot(f, main = main, cex.names = 0.7, cex.axis = 0.7,
                xlab = "Primer", ylab = "Number or reads",
                beside = TRUE, col = cols, las = 2)
        legend("topright",
               c(paste("Num.reads < percentile 0.01 =", q), "unidentified"),
               cex = 0.8, bty = "n", fill =  c("tomato", grey.colors(1)))
    dev.off()
}

## trimMIDs
##
## Description
##
##   Given a 'list' whose slots are 'ShortReadQ' objects associated each one of them with a specific
##   MID, the function trims the corresponding  MID primer from fasta and quality sequences
##
## Usage
##
##    trimMIDs(fq.ls, mids)
##
## Parameters
##
##     fq.ls : 'list' of 'ShortReadQ' objects (where each one corresponds to an specific MID).
##      mids : data.frame with identification (MID.ID) and sequence (MID.Seq) corresponding with each MID.
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##    mids <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    fq.ls <- splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)
##    trimMIDs(fq.ls, mids)

trimMIDs <- function(fq.ls, mids)
{
    out <- list()
    for(i in 1:nrow(mids))
    {
        fq <- fq.ls[[i]]
        pos <- regexpr(mids$MID.Seq[i], sread(fq))
        out[[i]] <- narrow(fq, as.numeric(pos) + nchar(mids$MID.Seq[i]), width(fq))
    }
    out[[i + 1]] <- fq

    names(out) <- names(fq.ls)

    return(out)
}


## splitByConsesus
##
## Description
##
##     Given a 'list' of 'ShortReadQ' objects, each one of them associated with a MID,
##     splits reads by consensus primers provided ina data.frame.
##
## Usage
##
##    splitByConsensus(fq.ls, mids, samples, primers, max.mm = 0, with.indels = FALSE)
##
## Parameters
##
##           fq.ls : 'list' of 'ShortReadQ' objects, where each one corresponds to an specific MID.
##            mids : data.frame with identification (MID.ID) and sequence (MID.Seq) corresponding with each MID.
##         samples : data.frame with the sample information (i.e. the targets)
##         primers : data.frame with identification (Primer.ID), amplicon name (Ampl.Name), consensus sequence (Primer.Seq),
##                   starting position of the consensus sequence in the reference sequence (Start) and the length of
##                   the consensus sequence (Num).
##          max.mm : integer indicating the maximum number of mismatches in each consensus primer. By default it is 0.
##     with.indels : logical value indicating if indels are allowed in consensus primer. By default it is FALSE.
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    mids <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    primers <- read.csv2(file = "primers.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    samples <- read.csv2(file = "samples.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##
##    fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##    fq.ls <- splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)
##    my.reads.ls <- trimMIDs(fq.ls, mids)
##
##    splitByConsensus(fq.ls = my.reads.ls, mids, samples, primers, max.mm = 3, with.indels = TRUE)

splitByConsensus <- function(fq.ls, mids, samples, primers, max.mm = 0, with.indels = FALSE)
{
    out <- list()
    
    mid.0 <- which(names(fq.ls)=="MID.0")
                   
    for(i in names(fq.ls)[-mid.0])
    {
        out[[i]] <- list()

        fq <- fq.ls[[i]]

        mid.id <- mids[i,]$MID.ID
        ampl.name <- samples[samples$MID.ID==mid.id, "Ampl.Name"]

        for(j in ampl.name)
        {
            out[[i]][[j]] <- list()
            for(k in unique(primers$Sense))
            {
                reads <- sread(fq)
                consensus <- primers[(primers$Ampl.Name == j) & (primers$Sense == k), "Primer.Seq"]
                hits <- vcountPattern(consensus, reads, max.mismatch = max.mm,
                                      with.indels = with.indels)
                out[[i]][[j]][[k]]  <- fq[-which(hits==0)]
                fq <- fq[-which(hits!=0)]
            }
        }
        out[[i]][["unidentified"]]  <- fq
    }

    return(out)
}


## summaryReads
##
## Description
##
##     Given a 'list' object generated with function 'splitByConsensus' yields a data.frame
##     suumarizing the splitting process. That is, for each amplicon and MID shows the number
##     of forward and reverse reads identified, as well as the number of unidentified reads
##     for each MID
##
## Usage
##
##    summaryReads(x, samples)
##
## Parameters
##
##           x : 'list' object with the results provided by the function 'splitByConsensus'
##     samples : data.frame with the sample information (i.e. the targets)
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    mids <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    primers <- read.csv2(file = "primers.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    samples <- read.csv2(file = "samples.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##
##    fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##    fq.ls <- splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)
##    my.reads.ls <- trimMIDs(fq.ls, mids)
##
##    r.ls <- splitByConsensus(fq.ls = my.reads.ls, mids, samples, primers, max.mm = 3, with.indels = TRUE)
##
##    summaryReads(x = r.ls, samples = samples)

summaryReads <- function(x, samples)
{
    out <- cbind(rbind(data.frame(Ampl.Name = rep(samples$Ampl.Name, each = 2),
                                  MID.ID = rep(paste0("MID.", samples$MID.ID), each = 2),
                                  Sense = c("fw", "rv")),
                       data.frame(Ampl.Name = "unidentified",
                                  MID.ID = paste0("MID.", unique(samples$MID.ID)),
                                  Sense = NA)),
                 Num.Reads = NA)
       
    for(i in 1:nrow(out))
    {
        amp   <- as.character(out[i, "Ampl.Name"])
        mid.i <- as.character(out[i, "MID.ID"])
        if(amp=="unidentified")
        {
            out[i, "Num.Reads"] <- length(x[[mid.i]][[amp]])
        }else{
            sns   <- as.character(out[i, "Sense"])
            out[i, "Num.Reads"] <- length(x[[mid.i]][[amp]][[sns]])
        }
    }
    
    return(out)
}

   
## consensusDiagram
##
## Description
##
##     Yields a pdf file that contains, for each amplicon, a bar plot of the number of forward
##     and reverse reads by MID primer
##
## Usage
##
##     consensusDiagram(x, file, main = "Bar plot of the number of reads by MID in gene")
##
## Parameters
##
##        x : data.frame resulting from 'summaryReads'
##     file : name of the output (.pdf) file where figures are saved
##     main : main title of the plot
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    fq <- readFastq(my.path, pattern = "reads.fastq", withIds = TRUE)
##    mids    <- read.csv2(file = "mids.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    samples <- read.csv2(file = "samples.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##    primers <- read.csv2(file = "primers.csv", header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
##
##    reads.mid <- splitByMIDs(fq, mids, max.start.pos = 5, max.mm = 0, with.indels = FALSE)
##    trimmed.reads.mid <- trimMIDs(fq.ls = reads.mid, mids = mids)
##    reads.cons <- splitByConsensus(fq.ls = trimmed.reads.mid, mids, samples, primers,
##                                   max.mm = 3, with.indels = TRUE)
##    summary.reads <- summaryReads(x = reads.cons, samples = samples)
##
##    consensusDiagram(x = summary.reads, file = "reads.by.amplicon.and.MID.pdf")

consensusDiagram <- function(x, file, main = "Bar plot of the number of reads by MID in gene")
{
    nr.amplicon <- split(x, f = factor(x$Ampl.Name))
    
    pdf(file)
        for(amp in names(nr.amplicon))
        {
            nr <- nr.amplicon[[amp]][, -1]

            if(all(is.na(nr$Sense)))
            {
                barplot(nr[, 3],
                        names = t(nr)[1,], las=2, xlab = "MID",  ylab = "Number or reads",
                        cex.names = 0.7, cex.axis = 0.7, col = "tomato",
                        main = paste(main, amp))
            }else{
                nr.compact <- reshape(nr,
                                      timevar = "Sense", idvar = "MID.ID", direction = "wide")
                colnames(nr.compact) <- c("MID.ID", "fw","rv")
                
                cols <- c(grey.colors(1), "grey")
                
                barplot(t(nr.compact)[-1,], 
                        names = t(nr.compact)[1,], col = cols, las = 2,
                        xlab = "MID",  ylab = "Number or reads",
                        cex.names = 0.7, cex.axis = 0.7, main = paste(main, amp))
                legend("topright",
                       c("Forward sequence", "Reverse sequence"),
                       cex = 0.8, bty = "n", fill =  c(grey.colors(1), "grey"))
            }
        }
    dev.off()
}
