## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Functions required by the Step number 1 of the pipeline - Quality Control of Raw Reads
##     (i.e. file proc1_qc-raw_data.R)
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.
##
## List of functions
##
##     buildFastq
##     runFastQC
##     readsStats
##     readsDist
##     readLengthsPlot
##     readQualityPlot
##     baseCallsFreq
##     baseCallsPlot


## buildFastq
##
## Description:
##
##   Run perl script 'fnaqual2fastq.pl' to convert a fasta file and its corresponding qual file to a fastq file
##
## Usage
##
##    buildFastq(pl.dir = getwd(), fasta.fn = "reads.fasta", qual.fn = "reads.qual", fastq.fn = "reads.fastq")
##
## Parameter(s)
##
##       pl.dir : path where is placed the perl script. In case of NULL, the function will take the working path.                
##     fasta.fn : character with the path and name to input fata file. By default "reads.fasta".
##      qual.fn : character with the path and name to input .qual file. By default "reads.qual".
##     fastq.fn : character with the path and name to output .fastq file. By default "reads.fastq".
##
## Details
##
##  'fnaqual2fastq.pl' is a modification/adaptation of perl script 'fastaQual2fastq.pl' courtesy of
##  'https://github.com/josephhughes/Sequence-manipulation'. The input file must have the extension .fasta or
##  .fna and the associated quality file must have the same name with extension .qual 
##
##  The input file must have the extension .fasta or .fna and the associated quality file must have the same name with
##  extension .qual
##
## Author
##
##     Jose Luis Mosquera
##
## Example(s)
##
##  perl.dir <- "/myproject/functions/perl"
##  data.dir <- "/myproject/data/run"
##  fasta <- file.path(data.dir, "reads.fna")
##  qual  <- file.path(data.dir, "reads.qual")
##  fastq <- file.path(data.dir, "reads.fastq")
##
##  buildFastq(pl.dir = perl.dir, fasta.fn = fasta, qual.fn = qual, fastq.fn = fastq)

buildFastq <- function(pl.dir = NULL, 
                      fasta.fn = "reads.fasta", qual.fn = "reads.qual", fastq.fn = "reads.fastq")
{
    if(is.null(pl.dir)) pl.dir <- getwd()
    
    system(paste("perl", file.path(pl.dir, "fnaqual2fastq.pl"), fasta.fn, qual.fn, ">", fastq.fn))
}


## runFastQC
##
## Description:
##
##   Executes software tool FastQC for a given fastq file
##
## Usage
##
##    runFastQC(fastq.fn, res.dir, fastqc.dir, mc.cores = 1)
##
## Parameter(s)
##
##       fastq.fn : character with the path and name to output .fastq file. By default "reads.fastq".
##        res.dir : character with the path to output files.
##     fastqc.dir : character with the path to the software tool FastQC.
##       mc.cores : Number of cores to use. By default 1.
##
## Author
##
##     Jose Luis Mosquera
##
## Example(s)
##
##     data.dir <- "/myproject/data/run"
##     fastq    <- file.path(data.dir, "reads.fastq")
##     res.dir <- "/myproject/results"
##     fastqc <- "/mysoftware/FastQC"
##
##     runFastQC(fastq.fn = fastq, res.dir = res.dir, fastqc.dir = fastqc, mc.cores = 4)

runFastQC <- function(fastq.fn, res.dir, fastqc.dir, mc.cores = 1)
{
    system(paste0(file.path(fastqc.dir, "fastqc"),  " --threads=", mc.cores,
	    " --outdir=", res.dir, " ", fastq.fn))
}


## readsStats
##
## Description
##
##   Descriptive statistics of short reads
##
## Usage
##
##   readStats(x)
##
## Parameters
##
##       x : 'DNAStringSet' object
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    filepath <- system.file("extdata", "someORF.fa", package="Biostrings")
##    fasta.info(filepath, seqtype="DNA")
##    x <- readDNAStringSet(filepath)
##    wd.sats <- readsStats(x)
##    wd.sats

readsStats <- function(x)
{
  wd <- width(x)

  n <- length(wd)
  stats <- as.data.frame(t(round(append(quantile(wd, c(0, 0.25, 0.5, 0.75, 1)), mean(wd), 3), 1)))
  names(stats) <- c("Min", "Q1",  "Median", "Mean", "Q3", "Max")
  out <- data.frame(N = n, stats)

  return(out)
}


## readsDist
##
## Description
##
##   Builds a data.frame for the reads lengths distribution
##
## Usage
##
##   readsDist(x)
##
## Parameters
##
##       x : 'DNAStringSet' object
##
## Details
##
##   Output data.frame shows the number of reads distributed allong a certain number of classes.
##   Upper and lower bounds of each class are the maximum and minimum reads lengths. Each class
##   ranges 50 integer numbers, and the whole distribution (that is considering all classes)
##   ranges from 0 read length to the next ceiling hundred of the maximum read length (e.g. if
##   max(reads lengths) = 802, then the upper bound will be 900)
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    filepath <- system.file("extdata", "someORF.fa", package="Biostrings")
##    fasta.info(filepath, seqtype="DNA")
##    x <- readDNAStringSet(filepath)
##    wd.dist <- readsDist(x)
##    wd.dist

readsDist <- function(x)
{
  wd <- width(x)
  n <- length(wd)

  wd.max <- max(wd)
  breaks <- seq(from = 0, to = ((wd.max) %/% 50) * 50 + 50, 50)

      abs.freq <- table(cut(wd, breaks = breaks))
  cum.abs.freq <- cumsum(abs.freq)
      rel.freq <- round((abs.freq / n) * 100, 2)
  cum.rel.freq <- round((cum.abs.freq / n) * 100, 2)

  out <- cbind(as.data.frame(abs.freq),
               as.data.frame(cum.abs.freq),
               as.data.frame(rel.freq)[, 2],
               as.data.frame(cum.rel.freq))
             #  (as.data.frame.table(abs.freq),
             #  as.data.frame.table(cum.abs.freq),#[, 2],
             #  as.data.frame.table(rel.freq),#[, 2],
             #  as.data.frame.table(cum.rel.freq),#[, 2])
  names(out) <- c("ReadsLength", "N", "CumN", "Per", "CumPer")

  return(out)
}


## readLengthsPlot
##
## Description
##
##   Descriptive statistics plots of short reads
##
## Usage
##
##   readLengthPlot(x, file, stats = NULL)
##
## Parameters
##
##       x : 'DNAStringSet' object
##    file : name of the output (.pdf) file where figures are saved
##   stats : data.frame with descriptive statistics associated with the shorts reads
##    main : main title of the plot
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    filepath <- system.file("extdata", "someORF.fa", package="Biostrings")
##    fasta.info(filepath, seqtype="DNA")
##    x <- readDNAStringSet(filepath)
##
##    readLengthsPlot(x, file = file.path(getwd(), "plot.pdf"))

readLengthsPlot <- function(x, file, stats = NULL, main = "Histogram of Reads Lengths")
{
   wd <- width(x)

   pdf(file)
      den.wd <- density(wd)
      tbl <- table(wd)
       plot(tbl, main = main, xlab = "Reads Lengths", ylab = "Number of Reads", col = "darkgrey")
      if(!is.null(stats))
      {
          abline(v = stats$Q1, col = "blue")
          abline(v = stats$Q3, col = "darkgreen")
          abline(v = stats$Mean, col = "tomato")
          abline(v = stats$Median, col = "orange")
          legend("topright", c("Q1", "Median", "Mean", "Q3"), cex = 0.8,
                 col = c("blue", "orange", "red", "darkgreen"), lwd = 2, lty=1, bty="n")
      }
   dev.off()
}

## readQualityPlot
##
## Description
##
##   Yields a pdf file with the densities of overall read quality per each lane
##
## Usage
##
##   readQualityPlot(x, file)
##
## Parameters
##
##       x : data.frame associated with the slot of 'readQualityScore' from a 'FastqQA' object
##    file : name of the output (.pdf) file where figures are saved
##    main : main title of the plot
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    qa.summary <- qa("reads.fastq", type="fastq")
##    rqs <- qa.summary[["readQualityScore"]]
##    readQualityPlot(x = rqs, file = file.path(getwd(), "readQualityPlot.pdf"))

readQualityPlot <- function(x, file, main = "Density of Overall Read Quality per Lane")
{
    x.lane <- split(x[, 1:2], f = x$lane)
    cols <- rainbow(length(x.lane))

    pdf(file)
        plot(x.lane[[1]],
             xlim = c(floor(min(x[, 1])), ceiling(max(x[, 1]))),
             ylim = c(0, round(max(x[, 2]), 2) + 0.01),
             col = cols[1], type = "l",
             xlab = "Average base quality", ylab = "Proportion of reads",
             main = main)
        if(length(x.lane) > 1)
        {
            for(i in 2:length(x.lane))
            {
                lines(x.lane[[1]], col = cols[i], type = "l")
            }
        }
        legend("topleft", names(x.lane), cex = 0.8, col = cols, lwd = 2, lty = 1, bty = "n")
    dev.off()
}


## baseCallsFreq
##
## Description
##
##   Yields a csv file with a table showing base calls frequencies over all reads per each lane
##
## Usage
##
##   baseCallsFreq(x, file = NULL)
##
## Parameters
##
##       x : data.frame associated with the slot of 'baseCalls' from a 'FastqQA' object
##    file : name of the output (.pdf) file where figures are saved. By default NULL
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    qa.summary <- qa("reads.fastq", type="fastq")
##    bc <- qa.summary[["baseCalls"]]
##    baseCallsFreq(x = bc, file = file.path(getwd(), "baseCallsPlot.pdf"))

baseCallsFreq <- function(x, file = NULL)
{
    f <- x / rowSums(x)

    x.melt <- melt(t(x))
    f.melt <- melt(t(f))

    out <- data.frame(Lane = x.melt[, 2], Base = x.melt[, 1],
                      N = x.melt[, 3], Freq. = round(f.melt[, 3], 5))
    if(!is.null(file))
    {
        write.csv2(x = out, file = file, quote = FALSE, row.names = FALSE)
    }

    return(out)
}


## baseCallsPlot
##
## Description
##
##   Yields a pdf file with a bar plot of base call frequency over all reads per each lane
##
## Usage
##
##   baseCallsPlot(x, file)
##
## Parameters
##
##       x : data.frame associated with the slot of 'baseCalls' from a 'FastqQA' object
##    file : name of the output (.pdf) file where figures are saved
##    main : main title of the bar plot
##
## Author
##
##     Jose Luis Mosquera
##
## Example
##
##    qa.summary <- qa("reads.fastq", type="fastq")
##    bc <- qa.summary[["baseCalls"]]
##    baseCallsPlot(x = bc, file = file.path(getwd(), "baseCallsPlot.pdf"))

baseCallsPlot <- function(x, file, main = "Bar Plot of Base Call Frequency Over All Reads per Lane")
{
    f <- x / rowSums(x)
    pdf(file)
        barplot(t(f), main = main,
                xlab = "Lane", ylab = "Base Frequency",
                beside = TRUE, col = c(grey.colors(4)[4:1], "tomato"))
        legend("topright", colnames(f), cex = 0.8, bty = "n",
               fill =  c(grey.colors(4)[4:1], "tomato"))
    dev.off()
}

