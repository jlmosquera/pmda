## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
## 
##     Process 5 : Functions associated with the comparisons between experimental
##     conditions in order to identify DMR (i.e proc5-comparisons.R
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.
##
## List of functions
##
##     crosstabs
##     crosstabsBySite
##     tables2Test
##     fisherTest
##     mtCorrection
##     plotOR
##     plotlistOR
##     summaryDMR


## crosstabs
##
## Description:
##
##   Given a data.frame with methylation status, groups and frequencies per each site,
##   generates a list where each component contains a crosstable for each experimental combination
##   of conditions
##
## Usage
##
##    crosstabs(x, mc.cores = 1)
##
## Parameter(s)
##
##            x : data.frame that contains methylation frequencies
##     mc.cores : Number of cores to use. By default 1
##
## Example(s)
##
##   met.cros[,1:4]
##   Methylated Group site1 site2
##   1        Yes     A    65   213
##   2        Yes     B    81   341
##   3        Yes     C    89   310
##   4         No     A 45565 45417
##   5         No     B 42106 41846
##   6         No     C 46498 46277
##
##   met.cros.site <- crosstabs(x = met.cros[,1:4], mc.cores = 6)
##   met.cros.site 
##   $site1
##     Yes    No
##   A  65 45565
##   B  81 42106
##   C  89 46498
##
##   $site2
##     Yes    No
##   A 213 45417
##   B 341 41846
##   C 310 46277

crosstabs <- function(x, mc.cores = 1)
{ 
    p <- ncol(x)
    out <- mclapply(3:p,
                    function(j, x)
                    {
                        out.df <- x[, c(1:2, j)]
                        n.names <- levels(out.df[, 2])
                        m.names <- levels(out.df[, 1])
                        out <- matrix(out.df[,3], nrow = length(n.names), ncol = length(m.names))
                        rownames(out) <- n.names
                        colnames(out) <- m.names

                        return(out)
                    },
                    x = x,
                    mc.cores = mc.cores)
    names(out) <- colnames(x)[3:p]

    return(out)    
}


## crosstabsBySite
##
## Description:
##
##     Given a 'list' of 'data.frame' (one per each context and amplicon) with methylation status,
##     groups and frequencies per each site, splits each 'data.frame' into a 'list' crosstables
##     for each experimental combination of conditions and site
##
## Usage
##
##     crosstabsBySite(x, mc.cores = 1)
##
## Parameter(s)
##
##            x : 'list' of 'data.frame' with methylation status, groups and frequencies per each site
##     mc.cores : Number of cores to use. By default 1
##
## Example(s)
##
##   met.summary.ls[1:2]
##   $CG.amp1
##     Methylated Group site1 site2
##   1        Yes     A    79   353
##   2        Yes     B    81   341
##   3        Yes     C    89   310
##   4         No     A 45565 45417
##   5         No     B 42106 41846
##   6         No     C 46498 46277
##   $CG.amp2
##     Methylated Group site1 site2
##   1        Yes     A    98   485
##   2        Yes     B    87   543
##   3        Yes     C    91   512
##   4         No     A 35175 43411
##   5         No     B 42236 41444
##   6         No     C 45491 49278
##
##   crosstabsBySite(x = met.summary.ls, mc.cores = 6)
 
crosstabsBySite <- function(x, mc.cores = 1)
{                            
    is.empty <- !all(unlist(lapply(x, nrow)==0))
     
    if(is.empty)
    {
        large.tables <- x
    }else{
        which.empty  <- which(unlist(lapply(x, nrow)==0))
        large.tables <- x[-which.empty]
    }
 
    out <- mclapply(large.tables,
                    function(tab, nc)
                    {
                        cross.tab <- crosstabs(x = tab, mc.cores = nc)

                        return(cross.tab)
                    },
                    nc = mc.cores,
                    mc.cores = mc.cores)
    
    return(out)
}


## tables2Test
##
## Description
##
##
## Usage
##
##     tables2Test(x, comp, mc.cores = 1)
##
## Argument(s)
##
##            x :
##         comp :
##     mc.cores : number of cores. By default it is 1.
##
##

tables2Test <- function(x, comp, mc.cores = 1)
{
    out <- list()
        
    context.amp <- names(x)
    m <- ncol(comp)
    groups <- colnames(comp)[-c(1, 2)]
        
    for(i in context.amp)
    {
        tab.ls = x[[i]]
        amp <- unlist(strsplit(i, "[.]"))[2]
        which.comp <- which(comp[,1]==amp)
        for(k in which.comp)
        {
            pos <- groups[comp[k, 3:ncol(comp)]>0]
            neg <- groups[comp[k, 3:ncol(comp)]<0]
        
            if(length(pos) > 2)
            {
                group.a <- mclapply(tab.ls,
                                    function(tab, rows)
                                    {
                                        new.mat <- rowSums(tab[rows, ])
                                        return(new.mat)
                                    },
                                    rows = pos,
                                    mc.cores = mc.cores)
            }else{
                group.a <- mclapply(tab.ls,
                                    function(tab, rows)
                                    {
                                        new.mat <- tab[rows, ]
                                        return(new.mat)
                                    },
                                    rows = pos,
                                    mc.cores = mc.cores)
            }
            
            if(length(neg) > 2)
            {
                group.b <- mclapply(tab.ls,
                                    function(tab, rows)
                                    {
                                        new.mat <- rowSums(tab[rows, ])
                                        return(new.mat)
                                    },
                                    rows = neg,
                                    mc.cores = mc.cores)
            }else{
                group.b <- mclapply(tab.ls,
                                    function(tab, rows)
                                    {
                                        new.mat <- tab[rows, ]
                                        return(new.mat)
                                    },
                                    rows = neg,
                                    mc.cores = mc.cores)
            }
            
            test.mat <- mclapply(1:length(tab.ls),
                                 function(l, group.a, group.b, labs)
                                 {
                                     new.mat <- rbind(group.a[[l]], group.b[[l]])
                                     rownames(new.mat) <- labs
                                     return(new.mat)
                                 },
                                 group.a = group.a,
                                 group.b = group.b,
                                 labs = unlist(strsplit(as.character(comp[k,2]), "_vs_")),
                                 mc.cores = mc.cores)
            names(test.mat) <- names(tab.ls)

            out[[i]][[as.character(comp[k,2])]] <- test.mat
        }
    }
        
    return(out)
}


## fisherTest
##
## Description
##
##
## Usage
##
##     fisherTest(x, mc.cores)
##
## Argument(s)
##
##            x :
##     mc.cores : number of cores
##
##

fisherTest <- function(x, mc.cores)
{
    out <- mclapply(x,
                    function(comp.ls, nc)
                    {
                        rc <- mclapply(names(comp.ls),
                                       function(comp, comp.ls, nc)
                                       {
                                           tab.ls <- comp.ls[[comp]]
                                           
                                           rls <- mclapply(tab.ls,
                                                           function(tab)
                                                           {
                                                               f <- fisher.test(tab,
                                                                                alternative = "two.sided")
                                                               f.tab <- cbind(f$estimate,
                                                                              f$conf.int[1],
                                                                              f$conf.int[2],
                                                                              f$p.value)
                                                               return(f.tab)
                                                           },
                                                           mc.cores = nc)
                                           rdf <- do.call("rbind", rls)
                                           rownames(rdf) <- names(tab.ls)
                                           colnames(rdf) <- paste(comp, c("OR", "Lower.OR", "Upper.OR",
                                                                          "Pvalue"), sep = ".")
                                           return(rdf)
                                       },
                                       comp.ls = comp.ls,
                                       nc = nc,
                                       mc.cores = nc)
                        names(rc) <- names(comp.ls)
                        
                        return(rc)
                    },
                    nc = mc.cores,
                    mc.cores = mc.cores)

    return(out)
}


## mtCorrection
##
## Description:
##
##
## Usage
##
##     mtCorrection(x, method = "fdr", mc.cores = 1)
##
##
## Parameter(s)
##
##           x : 
##      method : By default it is 'fdr'
##    mc.cores : number of cores. By default it is 1
##
## Example(s)
##
## 

mtCorrection <- function(x, method = "fdr", mc.cores = 1)
{
    out <- mclapply(fisher.test.ls,
                    function(comp.ls, method, nc)
                    {
                        tab.ls <- mclapply(comp.ls,
                                           function(tab, method)
                                           {
                                               which.pvals <- which(regexpr(".Pvalue", colnames(tab)) > 0)
                                               padj <- p.adjust(p = tab[, which.pvals], method = method)
                                               res  <- cbind(tab, padj)
                                               colnames(res)[ncol(res)] <- gsub(".Pvalue", ".Adj.Pvalue",
                                                                                colnames(tab)[which.pvals])
                                               
                                               return(res)
                                           },
                                           method = method,
                                           mc.cores = nc)
                        comp.df <- do.call("cbind", tab.ls)
                        
                        return(comp.df)
                    },
                    method = method,
                    nc = mc.cores,
                    mc.cores = mc.cores)

    return(out)
}


## plotOR
##
## Description:
##
##    Plots a figure of log2(OR) values for each site and its associated confidence interval.
##
## Usage
##
##    plotOR(x, alpha = 0.05, main = "log2(OR) for each CpG site")
##
## Argument(s)
##
##        x : a matrix
##    alpha : number between 0 and 1. It is the threshold to select OR based on FDR value. By default 0.05
##     main : a character for the title of the figure
##
## Example(s)
##
##   

plotOR <- function(x, alpha = 0.05, main = "log2(OR) for each CpG site")
{
        z <- x        
    sites <- nrow(z)
    z[, 1:3] <- log2(z[, 1:3])
        
    updown <- c(z[, 1:3])
    pos.inf.idx <- which(updown==Inf)
    neg.inf.idx <- which(updown==-Inf)
    inf.idx <- c(pos.inf.idx, neg.inf.idx)
        
    if(length(inf.idx)==0)
    {
        M <- max(abs(updown))
    }else{
        M <- max(abs(updown[-inf.idx]))
    }
        
#    M <- max(abs(z[, 1:3]))
    ymax <- ifelse(M < 2, 2, ceiling(M) + 1)

    z[pos.inf.idx] <- ymax
    z[neg.inf.idx] <- -ymax
            
    xx <- c(1:sites, sites:1)
    
    yy1 <- z[, 2]
    yy2 <- z[, 3]
    yy <- c(yy1, yy2[sites:1])
        
    max.idx <- which(z[, 1]==ymax)
    min.idx <- which(z[, 1]==-ymax)
        
    plot(xx, yy,
         xlab = "CpG sites", ylab = "log2(OR)", main =  main,
         ylim = c(-ymax, ymax),  xaxt="n", type = "n")
    axis(1, at = 1:sites, labels = 1:sites, las = 3, cex = 0.4)
    polygon(xx, yy, col = "dodgerblue", border = NA)
    abline(h = 0, col = "black")
    points(1:sites, z[, 1], col = "blue", pch = 20)
    points(max.idx, z[max.idx, 1], col = "purple", pch = 20)
    points(min.idx, z[min.idx, 1], col = "mediumslateblue", pch = 20)        
    sig.sites <- which(z[,5] < alpha)
    points(sig.sites, rep(-ymax, length(sig.sites)), col = "red", pch = 18)
    legend("topright", inset = .05,
           c(paste("FDR <", alpha), "log2(OR)",
             "log2(OR) = Inf", "log2(OR) = -Inf"),
           col = c("red", "blue", "purple", "mediumslateblue"),
           pch = c(18, 20, 20, 20))
}


## plotlistOR
##
## Description:
##
##    
##
## Usage
##
##    plotlistOR(x, mc.cores = 1, plotPDF = TRUE)
##
## Argument(s)
##
##           x : 
##    mc.cores : number of cores. By degfault it is 1
##    plotTRUE : TRUE by defaults
##
## Example(s)
##
##   

plotlistOR <- function(x, mc.cores = 1, plotPDF = TRUE)
{
    mclapply(names(x),
             function(context.amp, x)
             {
                 context.amp.split <- unlist(strsplit(context.amp, split= "[.]"))
                 context <- context.amp.split[1]
                 amp <-  context.amp.split[2]
                 
                 tab <- x[[context.amp]]
                 
                 tab.names <- colnames(tab)
                 which.padj <- which(regexpr(".Adj.Pvalue", tab.names)>0)
                 n.comp <- length(which.padj)
                 cols <- c(1, 1+ which.padj[-n.comp])
                 
                 for(i in 1:n.comp)
                 {
                     comp <- gsub(".OR", "", tab.names[cols[i]])

                     file <- file.path(.cmp, paste(context.amp, "plotOR", comp, sep = "."))
                     if(plotPDF)
                     {
                         pdf(paste(file, "pdf", sep = "."))
                     }else{
                         tiff(paste(file, "tiff", sep = "."),
                              width = 3200, height = 3200, units = "px", res = 800,   # with an 800 resolution gives you 3200/800 = 4 inches. 
                              pointsize = 9)
                     }       
                     comp <- gsub("_", " ", comp)
                     plotOR(x = tab[, cols[i]:which.padj[i]],
                            alpha = 0.05,
                            main = paste("log2(OR) for each site", context,
                                         "\nin comparison", comp))
                     dev.off()
                 }
             },
             x = x,
             mc.cores= mc.cores)
}


## summaryDMR
##
## Description:
##
##    Summary table describing the number of DMR for each context, amplicon, comparison
##    and criteria.
##
## Usage
##
##    
##
## Argument(s)
##
##           x : 
##    mc.cores : number of cores. By degfault it is 1
##    plotTRUE : TRUE by defaults
##
## Example(s)
##
##   

summaryDMR <- function(x, mc.cores = 1)
{                       

    num.sites.ls <- mclapply(x,
                            function(tab)
                            {
                                tab.names <- colnames(tab)
                                which.padj <- which(regexpr(".Adj.Pvalue", tab.names)>0)
                                n = nrow(tab)
                                
                                if(length(which.padj)>1)
                                {
                                    ns.0.01 <- colSums(tab[, which.padj] < 0.01)
                                    ns.0.05 <- colSums(tab[, which.padj] < 0.05)
                                }else{
                                    ns.0.01 <- sum(tab[, which.padj] < 0.01)
                                    ns.0.05 <- sum(tab[, which.padj] < 0.05)
                                }
                                  
                                comp <- gsub(".Adj.Pvalue", "", tab.names[which.padj])
                                ns <- data.frame(comp, n, ns.0.01, ns.0.05)
                                colnames(ns) <- c("Comparison", "Num.Sites", "Adj.Pvalue < 0.01",
                                                  "Adj.Pvalue < 0.05")
                                return(ns)
                            },
                            mc.cores = mc.cores)
    
    out.ls <- mclapply(names(num.sites.ls),
                       function(context.amp, num.sites.ls)
                       {
                           context.amp.ls <- unlist(strsplit(context.amp, split = "[.]"))
                           sum.tab <- data.frame(Context = context.amp.ls[1],
                                                 Gene = context.amp.ls[2],
                                                 num.sites.ls[[context.amp]])
                           return(sum.tab)
                       },
                       num.sites.ls = num.sites.ls,
                       mc.cores = mc.cores)
                     
    out <- do.call("rbind", out.ls)
    colnames(out) <- c("Context", "Gene", "Comparison", "Num.Sites",
                       "Adj.Pvalue < 0.01", "Adj.Pvalue < 0.05")
    return(out)
}
    
