## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Process 2: Preprocessing - splitting and trimming reads prepares reads for the
##     alignment process. It consists of the following steps: splitting reads by MID primer,
##     trimming MID primers, splitting reads by consensus primer, and quality control of reads
##     per each amplicon.
##
## Details
##
##     There is no trimming of consensus primer because software tool 'BiQ Analyzer HT' from the Max 
##     Plank Institut Bioinformatik (http://biq-analyzer-ht.bioinf.mpi-inf.mpg.de/) alreadey takes
##     into account such primers.
## 
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.


###################################################
## chunk 1: Create main output paths
###################################################

.pre <- file.path(.res, "preprocessing")

.pre.spl  <- file.path(.pre, "splitting")
.spl      <- file.path(.dat, "splitted")
.spl.mids <- file.path(.spl, "mids")
.spl.cons <- file.path(.spl, "consensus")
.align    <- file.path(.dat, "alignment")

if(!file.exists(.pre.spl)) dir.create(.pre.spl)
if(!file.exists(.spl)) dir.create(.spl)
if(!file.exists(.spl.mids)) dir.create(.spl.mids)
if(!file.exists(.spl.cons)) dir.create(.spl.cons)
if(!file.exists(.align)) dir.create(.align)


###################################################
## chunk 2: Load Packages
###################################################

library("ShortRead")


###################################################
## chunk 3: Load Functions
###################################################

source(file.path(.r, "splitting.R"))
source(file.path(.r, "qc.R"))


##################################################
## chunk 4: Load Data
##################################################

#if(!file.exists(links.fn)) createLinksFile(links.fn)

lanes <- read.csv2(file = file.path(.dat, lanes.fn),
                   header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

samples <- read.csv2(file = file.path(.dat, samples.fn),
                     header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

primers <- read.csv2(file = file.path(.dat, primers.fn),
                     header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

if(max(samples$MID.ID) > 0)
{
    mids <- read.csv2(file = file.path(.dat, mids.fn),
                      header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)
    rownames(mids) <- paste("MID", mids$MID.ID, sep = ".")
}

if(filtering)
{
    load(file = file.path(.dat, "reads.filtered.Rda"))
    fastq <- fastq.f2
        
    rm(filtered.f1)
}else{
    load(file = file.path(.dat, "reads.Rda"))
}

gc()


##################################################
## chunk 5: Splitting and Trimming by MID Primers
##################################################

if(run.split.MIDs)
{
    ## Split reads by MID primer

    reads.mid.ls <- splitByMIDs(fq = fastq, mids, max.start.pos,
                                max.mm = max.mm.mid, with.indels = with.indels.mid)

    ## Bar plot of the number of reads by MID primer

    primersDiagram(x = unlist(lapply(reads.mid.ls, length)),
                   file = file.path(.pre.spl, "reads.by.MID.pdf"),
                   main = "Bar Plot of the number of reads by MID primer", freqs = FALSE)

    ## Trim MID primer

    trimmed.reads.mid.ls <- trimMIDs(fq.ls = reads.mid.ls, mids = mids)

    ## Write fastq and fasta files

    for(i in names(trimmed.reads.mid.ls))
    {

        writeFastq(object = trimmed.reads.mid.ls[[i]],
                   file = file.path(.spl.mids, paste(i, "fastq", sep = ".")),
                   mode = "w", full = TRUE, compress = FALSE)

        writeFasta(object = trimmed.reads.mid.ls[[i]],
                   file = file.path(.spl.mids, paste(i, "fasta", sep = ".")))
    }

    ## Save data

    save(reads.mid.ls, trimmed.reads.mid.ls, file = file.path(.dat, "trimmed.reads.mid.Rda"))

}else{
    load(file = file.path(.dat, "trimmed.reads.mid.Rda"))
}

gc()


##################################################
## chunk 6: Splitting by Consensus Primers
###################################################

if(run.split.cons)
{
    reads.cons.ls <- splitByConsensus(fq.ls = trimmed.reads.mid.ls, mids, samples, primers,
                                      max.mm = max.mm.cons, with.indels = with.indels.cons)

    ## Write fastq and fasta files

    for(i in names(reads.cons.ls))
    {
        for(j in names(reads.cons.ls[[i]]))
        {
            if(j=="unidentified")
            {
                writeFastq(object = reads.cons.ls[[i]][[j]],
                           file = file.path(.spl.cons, paste(paste(i, j, sep = "_"),
                                            "fastq", sep = ".")),
                           mode = "w", full = TRUE, compress = FALSE)

                writeFasta(object = reads.cons.ls[[i]][[j]],
                           file = file.path(.spl.cons, paste(paste(i, j, sep = "_"),
                                            "fasta", sep = ".")))

            }else{
                .amp <- file.path(.align, j)
                if(!file.exists(.amp)) dir.create(.amp)
 
                for(k in names(reads.cons.ls[[i]][[j]]))
                {
                    writeFastq(object = reads.cons.ls[[i]][[j]][[k]],
                               file = file.path(.spl.cons, paste(paste(j, i, k, sep = "_"),
                                                "fastq", sep = ".")),
                               mode = "w", full = TRUE, compress = FALSE)

                    writeFasta(object = reads.cons.ls[[i]][[j]][[k]],
                               file = file.path(.spl.cons, paste(paste(j, i, k, sep = "_"),
                                                "fasta", sep = ".")))

                    writeFasta(object = reads.cons.ls[[i]][[j]][[k]],
                               file = file.path(.amp, paste(j, i,"fasta", sep = ".")))

                    writeFastq(object = reads.cons.ls[[i]][[j]][[k]],
                               file = file.path(.run, paste(j ,"fastq", sep = ".")),
                               mode = "a", full = TRUE, compress = FALSE)
                }
            }
        }
    }

    ## Summary and bar charts of the number of reads splitted

    summary.reads.cons <- summaryReads(x = reads.cons.ls, samples = samples)

    ## Write summary

    write.csv2(x = summary.reads.cons,
               file = file.path(.pre.spl, "summary.reads.splitted.csv"),
               quote = FALSE,
               row.names = FALSE)

    ## Bar plot of the number of forward and reverse reads by MID primer
  
 
    consensusDiagram(x = summary.reads.cons,
                     file = file.path(.pre.spl, "reads.by.amplicon.and.MID.pdf"),
                     main = "Bar plot of the number of reads by MID in gene") 

    
    ## Save data

    save(reads.cons.ls, file = file.path(.dat, "reads.cons.Rda"))

    ## Remove unnecessary objects
    
    rm(reads.mid.ls, trimmed.reads.mid.ls, summary.reads.cons)
    
}else{
    load(file = file.path(.dat, "reads.cons.Rda"))
}

gc()


###################################################
## chunk 7: FastQC of reads splitted by consensus primers 
###################################################

if(run.FastQC.consensus)
{
    for(amp in unique(primers$Ampl.Name))
    {
        .fastqc.amp <- file.path(.pre.spl, paste("fastqc", amp, sep ="_"))
        if(!file.exists(.fastqc.amp)) dir.create(.fastqc.amp)
    
        runFastQC(fastq.fn = file.path(.run, paste(amp, "fastq", sep = ".")),
                  res.dir = .fastqc.amp, fastqc.dir = .fastqc,
                  mc.cores = mc.cores)
    }
    
    ## Remove unnecessary objects

    rm(amp, .fastqc.amp)
    gc()
}

