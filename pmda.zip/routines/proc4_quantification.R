## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Process 4: Quantification process. For each context (i.e. CG, CHG or CHH) and region
##     of interest (i.e. gene or amplicon),
##     this script performs the following steps:
##
##        1) Pile up tables 'result.tsv' associated  with each MID, that were generated during the
##           alignment process by 'BiQ Analyzer HT', into one single table.
##        2) Generates several plots for assessing the quality of the alignment.
##        3) Quantifies (un)methylation for each site and generates statistical summaries for
##           describing the data.
##        4) Plots heatmaps of quantifications based on the beta values
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.


###################################################
## chunk 1: Create main output paths
###################################################

.res.align <- file.path(.res, "alignment")

.qnt <- file.path(.res, "quantification")

if(!file.exists(.qnt)) dir.create(.qnt)


###################################################
## chunk 1: Load Packages
###################################################

library("parallel")
library("gplots")


###################################################
## chunk 2: Load Functions
###################################################

source(file.path(.r, "quantification.R"))


##################################################
## chunk 3: Load Data
##################################################

samples <- read.csv2(file = file.path(.dat, samples.fn),
                     header = TRUE, sep = "\t", dec = ".", stringsAsFactors = FALSE)

targets <- read.table(file = file.path(.dat, targets.fn), header = TRUE, sep = "\t")

if(pile.up)
{
    ## Pile up and concatenates methylation alignment results by region and amplicon
        
    met <- pileupBiQResults(samples = samples, path = .res.align,
                            file = "results.tsv", mc.cores = mc.cores)
    
    ## Write methylation alignment results by region and amplicon
    
    for(i in names(met))
    {
        write.csv2(x = met[[i]],
                   file = file.path(.qnt, paste0(i, ".csv")),
                   quote = FALSE,
                   row.names = FALSE)
    }
        
    ## Save concatenated methylation alignment results

    save(met, file = file.path(.dat, "met.alignment.concatenated.Rda"))
}else{
    load(file = file.path(.dat, "met.alignment.concatenated.Rda"))
}
    
gc()


##################################################
## chunk 4: QA of Alignment
##################################################

for(context in cpg)
{
    plotQABiQ(x = met, region = context, lab = "Alignment.Score", main = "Alignment Score")
    plotQABiQ(x = met, region = context, lab = "Sequence.Identity", main = "% of Identities")
    plotQABiQ(x = met, region = context, lab = "Mean.Methylation",
              main = "% (Detected) Methylation Sites")
    plotQABiQ(x = met, region = context, lab = "Missing.Sites",
              main = "Missing Methylation Sites")
}

## Remove unnecessary objects

rm(region)
gc()


##################################################
## chunk 5: Quatification
###################################################

## Counting the number of (un)methylated sites per MID for each context
  
counts.mat.ls <- countsByRegion(met, pat.lab = "Methylation.Pattern",
                                sn.lab = "Sample", mc.cores = mc.cores)
  
## Computing beta values of sites per MIDs for each context

beta.mat.ls <- betasByRegion(met, pat.lab = "Methylation.Pattern",
                             sn.lab = "Sample", mc.cores = mc.cores)
      
## Computing M values of sites per MIDs for each context
  
M.mat.ls <- MsByRegion(met, pat.lab = "Methylation.Pattern",
                       sn.lab = "Sample", mc.cores = mc.cores)

## Write counts, betas and M values
  
write.csv.ls(x = counts.mat.ls, path = .qnt, suffix = "num.Meth.Sites",
             row.names = FALSE, mc.cores = mc.cores)
  
write.csv.ls(x = beta.mat.ls, path = .qnt, suffix = "beta.values",
             row.names = TRUE, mc.cores)
  
write.csv.ls(x = M.mat.ls, path = .qnt, suffix = "M.values",
             row.names = TRUE, mc.cores)

## Methylation pattern for each read by context

met.pat.ls <- metPattern(met, pat.lab = "Methylation.Pattern", mc.cores = mc.cores)

## Write methylation pattern per read for each context

write.csv.ls(x = met.pat.ls, path = .qnt, suffix = "Meth.Pattern",
             row.names = TRUE, mc.cores = mc.cores)

## Computation of frequencies for each context and MID excluding missing sites
  
targets.selected.ls <- midFreqs(met, targets, mc.cores = mc.cores)

## Write selected reads
  
write.csv.ls(x = targets.selected.ls, path = .qnt, suffix = "mid.freq",
             row.names = TRUE, mc.cores = mc.cores)

## Summary of frequencies for each site in each context
  
met.summary.ls <- metSummary(met, met.pat = met.pat.ls,
                             freqs = targets.selected.ls, mc.cores = mc.cores)
      
## Write summary
      
write.csv.ls(x = met.summary.ls, path = .qnt, suffix = "Met.Summary",
             row.names = TRUE, mc.cores = mc.cores)

## Save data

save(beta.mat.ls, file = file.path(.dat, "beta.values.Rda"))
save(met.summary.ls, file = file.path(.dat, "met.summary.Rda"))

## Remove unnecessary objects

rm()
gc()


###################################################
## chunk 6: Plot Heatmaps with beta values
###################################################

if(doHM)
{
    target.samples.order <- NULL #order(my.targets$Time, my.targets$Phenotype)
  
    mclapply(1:length(beta.mat.ls),
             function(k, my.names, x, targets, outDir, filename)
             {
                 i <- my.names[k]
             
                 if(all(is.na(x[[i]])))
                 {
                     print(NaN)
                 }else{
                     i.splitted <- unlist(strsplit(i, split = "\\."))

                     targets.idx <- which(targets$Gene==i.splitted[2])
                     my.targets <- targets[targets.idx, ]
                     if(!is.null(target.samples.order))
                     {
                         my.targets <- my.targets[target.samples.order, ]
                     }
                     
                     print(my.targets)

                     tiff(file.path(.qnt,paste(i, "heatmap.tiff", sep = ".")),
                          width = 800, height = 800, units = "px", res = 200, pointsize = 6)
                     plotHeatmp(x= y[[1]][, as.character(my.targets$MID)],
                                targets = my.targets,
                                var = experimental.condition,
                                main = "Heatmap of beta values")
                     dev.off()
                 }
             },
             my.names = names(beta.mat.ls),
             x = beta.mat.ls,
             targets = targets,
             outDir = cpgDir,
             filename = heatmap.fn,
             mc.cores = nc)

    gc()
}

