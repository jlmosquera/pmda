## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Description
##
##     Process 2: Preprocessing - filtering raw reads prepares reads for the
##     alignment process. It consists of the following steps: filetering raw
##     reads according to different criteria and a quality control of reads after
##     such filterings step.
## 
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.

###################################################
## chunk 1: Create main output paths
###################################################

.pre <- file.path(.res, "preprocessing")
.qcf <- file.path(.pre, "filtering")

if(!file.exists(.pre)) dir.create(.pre)
if(!file.exists(.qcf)) dir.create(.qcf)


###################################################
## chunk 2: Load Packages
###################################################

library("ShortRead")


###################################################
## chunk 3: Load Functions
###################################################

source(file.path(.r, "qc.R"))
source(file.path(.r, "splitting.R"))


##################################################
## chunk 4: Load Data Files
##################################################

load(file = file.path(.dat, "reads.Rda"))


###################################################
## chunk 5: Filtering raw reads 
###################################################

if((filtering) && !is.null(fastq.fn))
{
    ## Filter 1: removing reads that are less than min.len nucleotides
    
    fastq.f1 <- fastq[width(fastq) > min.len]

    ## Filter 2: trimming and filtering reads containing bases N
    
    fastq.f2 <- fastq.f1[nFilter()(fastq.f1)]  

    ## Write fastq file of raw reads filtered
  
    writeFastq(object = fastq.f2, file = file.path(.run, "reads.filtered.fastq"),
               mode = "w", full = TRUE, compress = FALSE)

    ## Write fasta file with raw reads filtered

    reads.filtered <- sread(fastq.f2)
    names(reads.filtered) <- id(fastq.f2)
  
    writeFasta(object = reads.filtered, file = file.path(.run, "reads.filtered.fasta"))
 
    ## Save .Rda of fastq objects associated with each filter
  
    save(fastq.f1, fastq.f2, file = file.path(.dat, "reads.filtered.Rda"))

    ## Summary of filterings
  
    filtering.stats <- rbind(readsStats(fastq), readsStats(fastq.f1), readsStats(fastq.f2)) 
    summary.filtering <- data.frame(Filtering.Criteria = c("(none)",
                                                           paste("reads with length <", min.len),
                                                          "remove and trim reads with N's"),
                                    filtering.stats)

    ## Write summary of filtering results
  
    write.csv2(x = summary.filtering,
               file = file.path(.qcf, "summary.filtering.raw.reads.csv"),
               quote = FALSE,
               row.names = FALSE)
    
    ## Remove unnecessary objects
    
    rm(reads.filtered, filtering.stats, summary.filtering)
    gc()
}


###################################################
## chunk 6: FastQC of filtered reads 
###################################################

if(run.FastQC.filtered)
{
    .fastqc.filtered <- file.path(.qcf, "fastqc_filtered_reads")
    if(!file.exists(.fastqc.filtered)) dir.create(.fastqc.filtered)
    
    runFastQC(fastq.fn = file.path(.run, "reads.filtered.fastq"),
              res.dir = .fastqc.filtered, fastqc.dir = .fastqc,
              mc.cores = mc.cores)

    ## Remove unnecessary objects

    rm(.fastqc.filtered)
    gc()
}

