## pmda - An R pipeline for finding Differentially Methylated Regions (DMR)
##
## Usage
##
##     1) Fill up the parameters with the appropriate value
##     2) Execute file 'run_pmda.R'
##
## Author
##
##     Jose Luis Mosquera
##
## License
##
##     pmda v 1.0.1 - Copyright (c) 2015 Jose Luis Mosquera - jlmosquera@gmail.com
##
##     Use and distribution subject to the terms of the GPL-2 license. See LICENSE for details.

###################################################
## chunk 1: R Output Options
###################################################

Sys.setlocale('LC_ALL','C')              # To avoid warnings due to language
options(width = 170)

mc.cores <- 1                            # Number of cores

###################################################
## chunk 2: Project Identification
###################################################

.project <- "<name_of_the_project>"      # Project name


###################################################
## chunk 3: Paths
###################################################

## Main path

.main.path <- "<path_to_the_project>" 

## Basic structure

.wd <- file.path(.main.path, .project)               # Working path
setwd(.wd)

.dat <- file.path(.wd, "data")                       # Data
.fun <- file.path(.wd, "functions")                  # R functions
.res <- file.path(.wd, "results")                    # Results

## Software paths

.r      <- file.path(.fun, "R")                   # path name to R functions
.perl   <- file.path(.fun, "perl")                # path name to perl scripts
.fastqc <- "<path_to_FastQC>"                     # path name to software tool 'FastQC'
.biq    <- "<path_to_BiQAnalyzerHT>"              # path name to software tool 'BiQ_Analyzer'


###################################################
## chunk 4: Quality Control of Raw Data
###################################################
##
## Parameters associated with file: 'proc1_qc_raw_reads.R' 
##

## 1. FastQC of raw reads

run.FastQC.raw   <- TRUE        # run software FastQC for raw reads
convert.to.fastq <- TRUE        # TRUE if does not exist a .fastq file, but fasta.fn and qual.fn
                                # exist. FALSE is any other case
.run <- file.path(.dat, "run")  # path name to .fasta and .qual files
fasta.fn <- "reads.fasta"       # file name of the file with fasta sequences. NULL, otherwise
qual.fn  <- "reads.qual"        # file name of the file with qual sequences. NULL, otherwise

fastq.fn <- "reads.fastq"       # file name of the file with fastq sequences. NULL, otherwise

## 2. Load Data Files

lanes.fn <- "lanes.csv"         # file name of the file with lanes

save.reads <- TRUE              # TRUE saves in a file called 'reads.Rda' an object with raw reads,
                                # and in case of having a fastq file, it also save an object with
                                # fastq sequences. FALSE loads the object(s) mentioned above 

## 3. QC of raw reads 

run.QC.raw <- TRUE              # TRUE builds statistics summaries and plots


###################################################
## chunk 5: Pre-processing: Filtering Raw Reads
###################################################
##
## Parameters associated with file: 'proc2_preprocessing_fileterin_raw_reads.R' 
##

## 1. Filtering raw reads

filtering <- TRUE               # TRUE applies different filtering criteria to raw reads

min.len <- 150                  # minimum read length accepted for data analysis

## 2. FastQC of filtered reads

run.FastQC.filtered <- TRUE     # run software FastQC for raw reads


###################################################
## chunk 6: Pre-processing: Splitting and Trimming
###################################################
##
## Parameters associated with file: 'proc2_preprocessing_splitting_and_trimming_reads.R' 
##

## 1. Load Data Files

samples.fn <- "samples.csv"     # file name of the file with sample targets info
primers.fn <- "primers.csv"     # file name of the file with consensus primer sequences
mids.fn    <- "mids.csv"        # file name of the file with MID primer sequences

## 2. Splitting and trimming reads by MID primers

run.split.MIDs <- TRUE          # TRUE runs steps splitting and trimming reads by MID primers
                                # FALSE loads reads already splitted and trimmed

max.start.pos   <- 5            # Maximum starting position of primers
max.mm.mid      <- 0            # Maximum number of mismatches in each MID primer
with.indels.mid <- FALSE        # Indels are not allowed in MID primer

## 3. Splitting reads by consensus primers

run.split.cons <- TRUE          # TRUE runs step splitting by consensus primers

max.mm.cons       <- 3          # Maximum number of mismatches in each consensus primer
with.indels.cons  <- TRUE       # Indels are not allowed in consensus primers

## 4. FastQC of reads splitted by consensus primers

run.FastQC.consensus <- TRUE    # run software FastQC for reads splitted by consensus


###################################################
## chunk 7: Aligment process
###################################################
##
## Parameters associated with file: 'proc3_aligment.R' 
##

cpg <- c("CG", "CHG", "CHH")    # Contexts where methylation sites in the reference sequence
                                # must be found

###################################################
## chunk 8: Quantification
###################################################
##
## Parameters associated with file: 'proc4_quantification.R' 
##

## 1. Load Data Files

targets.fn <- "targets.txt"     # file name of the file with targets info of each sample

pile.up <- TRUE                 # TRUE pile up all 'result.tsv' generated by alignment.
                                # FALSE loads concatenated tables resulting from the pile up step

## Plot heatmaps with beta values

target.samples.order <- NULL    # Numeric vector indicating the order in which samples should be shown
                                # NULL, which is the parametrization by default, takes the order of
                                # samples in targets.fn file

experimental.condition <- "Group"


###################################################
## chunk 8: Selection of DMR
###################################################
##
## Parameters associated with file: 'proc5_comparisons.R' 
##

comparisons.fn <- "comparisons.txt"      # file name of the file with contrasts matrix

